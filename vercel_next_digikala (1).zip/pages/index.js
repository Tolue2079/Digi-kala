import React, { useState } from "react";

const products = [
  { id: 1, name: "گوشی موبایل سامسونگ", price: 12500000, image: "https://via.placeholder.com/150" },
  { id: 2, name: "هدفون بی‌سیم شیائومی", price: 850000, image: "https://via.placeholder.com/150" },
  { id: 3, name: "لپ‌تاپ ایسوس", price: 32500000, image: "https://via.placeholder.com/150" },
];

export default function Home() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    const existingItem = cart.find((item) => item.id === product.id);
    if (existingItem) {
      setCart(
        cart.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        )
      );
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const removeFromCart = (productId) => {
    setCart(cart.filter((item) => item.id !== productId));
  };

  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckout = async () => {
    const response = await fetch("/api/payment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount: totalPrice }),
    });
    const data = await response.json();
    if (data.url) {
      window.location.href = data.url;
    }
  };

  return (
    <div style={{ maxWidth: "800px", margin: "auto", padding: "20px", fontFamily: "sans-serif", direction: "rtl" }}>
      <h1 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "20px" }}>فروشگاه تستی دیجی‌کالا</h1>
      <div style={{ display: "grid", gap: "20px", gridTemplateColumns: "1fr 1fr 1fr" }}>
        {products.map((product) => (
          <div key={product.id} style={{ border: "1px solid #ccc", padding: "10px", borderRadius: "10px" }}>
            <img src={product.image} alt={product.name} style={{ width: "100%", height: "150px", objectFit: "cover" }} />
            <h2 style={{ fontSize: "16px", margin: "10px 0" }}>{product.name}</h2>
            <p style={{ color: "green" }}>{product.price.toLocaleString()} تومان</p>
            <button onClick={() => addToCart(product)} style={{ marginTop: "10px", padding: "6px 12px", backgroundColor: "#1e88e5", color: "white", border: "none", borderRadius: "5px" }}>
              افزودن به سبد خرید
            </button>
          </div>
        ))}
      </div>

      <div style={{ marginTop: "40px" }}>
        <h2 style={{ fontSize: "20px", fontWeight: "bold" }}>سبد خرید</h2>
        {cart.length === 0 ? (
          <p>سبد خرید خالی است.</p>
        ) : (
          <>
            <ul>
              {cart.map((item) => (
                <li key={item.id}>
                  {item.name} × {item.quantity} — {item.price.toLocaleString()} تومان
                  <button onClick={() => removeFromCart(item.id)} style={{ marginRight: "10px", color: "red" }}>
                    حذف
                  </button>
                </li>
              ))}
            </ul>
            <p style={{ marginTop: "10px" }}>مبلغ کل: {totalPrice.toLocaleString()} تومان</p>
            <button onClick={handleCheckout} style={{ marginTop: "10px", padding: "8px 16px", backgroundColor: "green", color: "white", border: "none", borderRadius: "5px" }}>
              پرداخت
            </button>
          </>
        )}
      </div>
    </div>
  );
}
