export default function handler(req, res) {
  const { amount } = req.body;
  // Simulate getting Authority from Zarinpal or other gateway
  const dummyAuthority = "TEST1234567890";
  const redirectUrl = `https://www.zarinpal.com/pg/StartPay/${dummyAuthority}`;
  res.status(200).json({ url: redirectUrl });
}
